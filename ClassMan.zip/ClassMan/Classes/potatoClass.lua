local Potato = {
	type="Rooster",
	size=1
}

function Potato:new( ... )
	local newSpud = ... or {}
	setmetatable(newSpud, self)
	self.__index = self

	newSpud.image = newSpud:loadImages{}

	return newSpud
end --function Potato:new

function Potato:setSize(amount)
	self.size = amount
	return
end

function Potato:getPosition()
	return self.size
end

function Potato:setX(amount)
	self.image.x = amount
	return
end

function Potato:setY(amount)
	self.image.y = amount
	return
end

function Potato:loadImages()

	--Here is where I can't get it to load the image
	local image = display.newImageRect( "Assets/potato.png", 60, 80 )

	return image
end


return Potato